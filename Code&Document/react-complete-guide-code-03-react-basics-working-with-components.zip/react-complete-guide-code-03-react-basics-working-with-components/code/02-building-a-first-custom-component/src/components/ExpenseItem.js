function ExpenseItem() {
  return <h2>Expense item!</h2>;
}

export default ExpenseItem;
